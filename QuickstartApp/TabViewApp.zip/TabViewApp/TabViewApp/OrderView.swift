//
//  OrderView.swift
//  TabViewApp
//
//  Created by Nikhil Challagulla on 11/7/23.
//

import Foundation
import SwiftUI

struct DaysView: View {
    
    @State var showView = false
    
    var body: some View {
        VStack {
            Snowflake()

            Spacer()
            HStack {
                Spacer()
                Text("Days")
                Spacer()
            }
            Spacer()
        }
        .background(Color.red.edgesIgnoringSafeArea(.all))
        
    }
}

struct HoursView: View {
    var body: some View {
        VStack {
            Spacer()
            HStack {
                Spacer()
                Text("Hours")
                Spacer()
            }
            Spacer()
        }
        .background(Color.red.edgesIgnoringSafeArea(.all))
    }
}

struct Snowflake: View {
    @State private var snowflakeOffset: CGPoint = CGPoint(x: -100, y: 1)

    var body: some View {
        
        ForEach(0..<10) { i in
            Image(systemName: "snow")
                .font(.title)
                .offset(x: snowflakeOffset.x * CGFloat(i), y: snowflakeOffset.y * CGFloat(i))
                .onAppear {
                    withAnimation(Animation.linear(duration: 30).repeatForever(autoreverses: false)) {
                        self.snowflakeOffset = CGPoint(x: Double.random(in: -100...UIScreen.main.bounds.width), y: Double(UIScreen.main.bounds.height))
                    }
                }
        }
    }
}
