//
//  TabViewAppApp.swift
//  TabViewApp
//
//  Created by Nikhil Challagulla on 11/7/23.
//

import SwiftUI

@main
struct TabViewAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
