//
//  MainView.swift
//  TabViewApp
//
//  Created by Nikhil Challagulla on 11/7/23.
//

import Foundation
import SwiftUI
//
//struct MainView: View {
//    var body: some View {
//        TabView {
//            ContentView()
//                .tabItem {
//                    Label("Menu", systemImage: "list.dash")
//                }
//
//            OrderView()
//                .tabItem {
//                    Label("Order", systemImage: "square.and.pencil")
//                }
//        }
//    }
//}
//

