//
//  ContentView.swift
//  TabViewApp
//
//  Created by Nikhil Challagulla on 11/7/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Spacer()
            HStack {
                Spacer()
                
                TabView {
                    
                    DaysView()
                        .tabItem {
                            Label("Days", systemImage: "square.and.pencil")
                        }
                    HoursView()
                        .tabItem {
                            Label("Hours", systemImage: "square.and.pencil")
                        }
                }
                .accentColor(Color.white)
                
                Spacer()
            }
            Spacer()
        }
        .onAppear() {
            UITabBar.appearance().barTintColor = .blue
        }
        .background(Color.red.edgesIgnoringSafeArea(.all))
    }
}

#Preview {
    ContentView()
}
